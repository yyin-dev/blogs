///////////////////////////////////////////////////////////////////////////////
//                   
// Main Class File:	P1.java
// Semester:        CS 536, Spring 2020
//
// Author:          Yue Yin
// Email:			yin64@wisc.edu
// 
///////////////////////////////////////////////////////////////////////////////

/**
 * P1 
 * 
 * This is the test class for two classes: SymTable and Sym. 
 * 
 * Sym provides the following operations:
 * 		Sym(String type)	-- no-arg constructor
 * 		String getType()	-- return this Sym's type
 * 		String toString()	-- Return this Sym's type
 * The operations are tested in testSymClass method.
 * 
 * SymTable provides the following operations:
 * 		SymTable()							-- non-arg constructor
 * 		void addDecl(String name, Sym sym) 	-- Add a declaration to the symbol 
 * 			throws DuplicateSymException, 	   table.
 * 				   EmptySymTableException	
 * 		void addScope()						-- Add a new, empty HashMap to the 
* 											   front of the list.
 * 		Sym lookupLocal(String name)		-- If the first HashMap in the list 
 * 											   contains name as a key, return 
 * 											   the associated Sym; otherwise, 
 * 											   return null.
 * 		Sym lookupGlobal(String name)		-- If any HashMap in the list 
 * 											   contains name as a key, return 
 * 											   the first associated Sym; 
 * 											   otherwise, return null.
 * 		void removeScope() 
 * 			throws EmptySymTableException	-- Remove the HashMap from the 
 * 											   front of the list.
 * 		void print()						-- Debugging method.
 * The operations are tested in testSymTableClass method.
 */

public class P1 {
	public static void main(String[] args) {
		/* Test Sym class */
		testSymClass();

		/* Test SymTable class */
		testSymTableClass();
	}

	/**
	 * Test operations provided by Sym class.
	 */
	private static void testSymClass() {
		Sym symTest = new Sym("int");

		// Test getType()
		if (symTest.getType() != "int") {
			System.out.println("getType() returns inconsistent result!");
		}

		// Test toString()
		if (symTest.toString() != "int") {
			System.out.println("toString() returns inconsistent result!");
		}
	}

	/**
	 * Test operations provided by SymTable class.
	 */
	private static void testSymTableClass() {
		SymTable symTable = new SymTable();

		String expected;
		
		/* Test print() method */
		symTable.print();
		expected = "{}";
		printExpected(expected);
		/* End of Test print() method */

        // Sym instances for testing SymTable class, with corresponding names.
        Sym intSym = new Sym("int");        // name: myInt
		Sym doubleSym = new Sym("double");  // name: myDouble
        Sym charSym1 = new Sym("char");     // name: myChar1
		Sym charSym2 = new Sym("char");     // name: myChar2

		/* Test addDecl method */
		// Test illegal argument
		boolean illegalArgExceptionThrown = false;
		try {
			symTable.addDecl(null, intSym);
		} catch (IllegalArgumentException e) {
			illegalArgExceptionThrown = true;
		} catch (Exception e) {
			System.out.println("Unexpected Excetpion!");
		} finally {
			if (!illegalArgExceptionThrown) {
				System.out.println("IllegalArgumentException should be thrown!");
			}
		}

		illegalArgExceptionThrown = false;
		try {
			symTable.addDecl("myInt", null);
		} catch (IllegalArgumentException e) {
			illegalArgExceptionThrown = true;
		} catch (Exception e) {
			System.out.println("Unexpected Excetpion!");
		} finally {
			if (!illegalArgExceptionThrown) {
				System.out.println("IllegalArgumentException should be thrown!");
			}
		}

		illegalArgExceptionThrown = false;
		try {
			symTable.addDecl(null, null);
		} catch (IllegalArgumentException e) {
			illegalArgExceptionThrown = true;
		} catch (Exception e) {
			System.out.println("Unexpected Excetpion!");
		} finally {
			if (!illegalArgExceptionThrown) {
				System.out.println("IllegalArgumentException should be thrown!");
			}
		}

		// Add myInt and myDouble to symTable
		try {
			symTable.addDecl("myInt", intSym);
			symTable.addDecl("myDouble", doubleSym);
		} catch(Exception e) {
			System.out.println("Unexpected exception!");
		}

		// Add duplicate of myInt
		boolean duplicateSymExceptionThrown = false;
		try {
			symTable.addDecl("myInt", intSym);
		} catch (DuplicateSymException e) {
			duplicateSymExceptionThrown = true;
		} catch (Exception e) {
			System.out.println("Unexpected exception!");
		} finally {
			if (!duplicateSymExceptionThrown) {
				System.out.println("DuplicateSymException should be thrown!");
			}
		} 
		/* End of Test addDecl method */

		/* Test print() method */
		symTable.print();
		expected = "{myInt=int, myDouble=double}";
		printExpected(expected);
		/* End of Test print() method */

		/* Test addScope method */
		symTable.addScope();
		/* End of Test addScope method */

		/* Test print() method */
		symTable.print();
		expected = "{}\n"	
				 + "{myInt=int, myDouble=double}";
		printExpected(expected);
		/* End of Test print() method */

		// Create a new scope and charSym1, charSym2 to symTable. 
		try {
			symTable.addDecl("myChar1", charSym1);
			symTable.addDecl("myChar2", charSym2);
		} catch (Exception e) {
			System.out.println("Unexpected exception!");
		}

		/* Test print() method */
		symTable.print();
		expected = "{myChar1=char, myChar2=char}\n"	
				 + "{myInt=int, myDouble=double}";
		printExpected(expected);
		/* End of Test print() method */

		/* Test lookupLocal method (1) */
		try {
			if (symTable.lookupLocal("myChar1") != charSym1) {
				System.out.println("Inconsistent!");
			}
			if (symTable.lookupLocal("myChar2") != charSym2) {
				System.out.println("Inconsistent!");
			}
			if (symTable.lookupLocal("myInt") != null) {
				System.out.println("Inconsistent!");
			}
			if (symTable.lookupLocal("myDouble") != null) {
				System.out.println("Inconsistent!");
			}
			if (symTable.lookupLocal("foo") != null) {
				System.out.println("Should not found anything!");
			}
		} catch (EmptySymTableException e) {
			System.out.println("Unexpected EmptySymTableException!");
		} 
		/* End of Test lookupLocal method (1) */

		// Sym instances with same name as previous ones
		Sym intSym2 = new Sym("int"); 		// name: myInt
		Sym doubleSym2 = new Sym("double"); // name: myDouble
		
		try {
			symTable.addScope();
			symTable.addDecl("myInt", intSym2);
			symTable.addDecl("myDouble", doubleSym2);
		} catch (Exception e) {
			System.out.println("Unexpected exception!");
		}

		/* Test print() method */
		symTable.print();
		expected = "{myInt=int, myDouble=double}\n"
				 + "{myChar1=char, myChar2=char}\n"	
				 + "{myInt=int, myDouble=double}";
		printExpected(expected);
		/* End of Test print() method */

		/*
		 * Current symTable:
		 * {myDouble=double(doubleSym2), myInt=int(intSym2)}
		 * {myChar2=char, myChar1=char}
		 * {myDouble=double(doubleSym), myInt=int(intSym)}
		 */

		/* Test lookupLocal method (2) */
		try {
			if (symTable.lookupLocal("myInt") != intSym2) {
				System.out.println("Inconsistent!");
			}
			if (symTable.lookupLocal("myDouble") != doubleSym2) {
				System.out.println("Inconsistent!");
			}
		} catch (EmptySymTableException e) {
			System.out.println("Unexpected EmptySymTableException!");
		} 
		/* End of Test lookupLocal method (2) */

		/* Test lookupGlobal method */
		try {
			if (symTable.lookupGlobal("myDouble") != doubleSym2) {
				System.out.println("Inconsistent!");
			}
			if (symTable.lookupGlobal("myInt") != intSym2) {
				System.out.println("Inconsistent!");
			}
			if (symTable.lookupGlobal("myChar1") != charSym1) {
				System.out.println("Inconsistent!");
			}
			if (symTable.lookupGlobal("myChar2") != charSym2) {
				System.out.println("Inconsistent!");
			}
		} catch (Exception e) {
			System.out.println("Unexpected exception!");
		} 
		/* End of Test lookupGlobal method */

		/* Test removeScope */
		try {
			// 1st remove
			symTable.removeScope();

			/* Test print() method */
			symTable.print();
			expected = "{myChar1=char, myChar2=char}\n"	
					 + "{myInt=int, myDouble=double}";
			printExpected(expected);
			/* End of Test print() method */

			// 2nd remove
			symTable.removeScope();

			/* Test print() method */
			symTable.print();
			expected = "{myInt=int, myDouble=double}";
			printExpected(expected);
			/* End of Test print() method */

			// 3rd remove
			symTable.removeScope();

			/* Test print() method */
			symTable.print();
			expected = "";
			printExpected(expected);
			/* End of Test print() method */
		} catch (EmptySymTableException e) {
			System.out.println("Unexpected EmptySymTableException!");
		}

		boolean emptySymTableExceptionThrown = false;
		try {
			symTable.removeScope();
		} catch (EmptySymTableException e) {
			emptySymTableExceptionThrown = true;
		} finally {
			if (!emptySymTableExceptionThrown) {
				System.out.println("EmptySymTableException should be thrown!");
			}
		}
		/* End of Test removeScope */
	}

	private static void printExpected(String s) {
		System.out.println("Expected Sym Table (order within map can differ)");
		System.out.println(s);
		System.out.println();
	}
}
