/**
 * DuplicateSymException
 * 
 * Instance of this class can be thrown by SymTable when there's a duplicate
 * of symbol.
 */
public class DuplicateSymException extends Exception {

}
